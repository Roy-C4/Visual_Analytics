import pandas as pd

def read():
    df = pd.read_csv('./world-happiness-report-2021.csv')
    #preprocess
    
    return df